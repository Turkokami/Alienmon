# Handoff for Claude in Chrome: update the ElevenLabs audiobook "Alienmon Book 1"

## Your task
You are updating my existing ElevenLabs Studio project **"Alienmon Book 1"** (the audiobook of *Alienmon: The Kessler Signal*). It was built from the first edition of the book (Oct 12). The book has since been revised. Change ONLY the text that changed and regenerate ONLY those parts, so I don't pay to re-render the whole novel.

Chapters with **no changes: Prologue, Chapter 11 and Chapter 23.** Don't touch them.

## Changed chapters
| Ch | Title | Mode | Edits | New words to generate |
|---|---|---|---|---|
| 1 | The Night the Bridge Hummed | paragraph edits | 6 | 491 |
| 2 | Zib | paragraph edits | 1 | 82 |
| 3 | Canyon Rivals | paragraph edits | 5 | 1,039 |
| 4 | The Cactus Garden Catch | paragraph edits | 8 | 1,278 |
| 5 | Leaving Dustmere | paragraph edits | 4 | 2,365 |
| 6 | The Stowaway | paragraph edits | 4 | 217 |
| 7 | The Gate That Woke | paragraph edits | 4 | 1,061 |
| 8 | The Iron Orphans | paragraph edits | 7 | 1,046 |
| 9 | Like Father, Like Kit | whole chapter | 6 | 2,657 |
| 10 | Launch Clearance | paragraph edits | 5 | 1,587 |
| 12 | Rival in the Lantern Marsh | paragraph edits | 14 | 1,818 |
| 13 | Lost in the Mushroom Maze | paragraph edits | 8 | 1,789 |
| 14 | Plazmet Ignites | paragraph edits | 8 | 2,082 |
| 15 | Port Ember | paragraph edits | 5 | 459 |
| 16 | Ghost Ship | paragraph edits | 10 | 516 |
| 17 | Harbor Under Siege | whole chapter | 13 | 2,427 |
| 18 | Captain's Orders | whole chapter | 7 | 2,389 |
| 19 | Sola's Choice | paragraph edits | 10 | 1,357 |
| 20 | City of Lights | paragraph edits | 6 | 1,411 |
| 21 | Pirate Radio | paragraph edits | 1 | 378 |
| 22 | Static on the Line | paragraph edits | 10 | 1,694 |
| 24 | Temple of Voices | whole chapter | 13 | 2,688 |
| 25 | Murals of Ystra | paragraph edits | 5 | 421 |
| 26 | The Crater Four | paragraph edits | 3 | 252 |

About 31,504 words need generating, about a third of the book. Four chapters (9, 17, 18, 24) changed so much that you replace the whole chapter text. The rest are paragraph-by-paragraph edits.

## How to work (follow exactly)
1. Open ElevenLabs (elevenlabs.io), go to **Studio**, open the project **Alienmon Book 1**. If you can't find it or I'm not signed in, stop and tell me.
2. Before editing, look at how the project is voiced. Note which voice is used for the Narrator, Rook, Kit, Sola, Dr. Vashti, Hank, Pell, Strand, Admin Vex, Director Thorne, Liss, Captain Marsh, DJ Static and anyone else, and how Zib's "Bip" is handled. Write this cast list down in your log; you'll reuse it for new lines.
3. Work **one chapter at a time, in order**, using that chapter's section in this file.
   - **Paragraph edits:** for each edit, find the OLD TEXT in the Studio editor. Use the "Find" anchor (the opening words of the first paragraph and the closing words of the last). Use the browser's find (Ctrl+F) on the opening words if needed. Select from the start of the first old paragraph to the end of the last old paragraph, delete it, and paste the NEW TEXT, keeping one paragraph per line break exactly as given. For INSERT edits, click at the end of the named paragraph, press Enter, and paste. For DELETE edits, remove the paragraph(s).
   - **Whole-chapter replacement:** keep the chapter and its title. Select all the text in the chapter body, delete it, and paste the NEW CHAPTER TEXT.
   - Paste plain text only. No formatting, no "> " quote marks (those only mark the old text in this file), no headings.
4. **Assign voices** to every new or changed paragraph, the same way the rest of the project is voiced:
   - Narration goes to the Narrator voice.
   - Quoted dialogue goes to the speaking character's voice (split a paragraph's quote onto the character voice if the project does that elsewhere).
   - New minor speakers keep to existing voices: a Helix grunt named Brann, a young grunt, Fenna, Mina and others. Reuse a matching minor/extra voice the project already has, otherwise use the Narrator. List every new speaker and the voice you chose in your log.
   - **Tone change for Helix:** Pell and Strand are no longer a comedy duo. Pell is calm, clipped and certain; Strand is quiet and uneasy; Vex is icy. If their existing voices are clearly comic or cartoonish, **stop and ask me** before changing voices or voice settings.
5. **Generate only what changed.** Studio marks edited paragraphs as not yet converted. Use the chapter's convert/generate button, which only renders unconverted paragraphs (or regenerate the changed paragraphs one by one). **Never use "Convert whole project" or regenerate unchanged chapters.** Before generating, check the credit cost shown. If it looks like it will regenerate the whole book, stop and ask me.
6. Spot-listen to the first and last changed paragraph in each chapter: the right voice, no cut-off words, and the pronunciations below.
7. Once every changed chapter is done, export/download the updated chapters (or the whole audiobook if Studio only exports everything; exporting doesn't cost credits) and tell me where the files are.

## Pronunciations (add to the project's pronunciation dictionary if they come out wrong)
Alienmon = AY-lee-en-mon · Plazmo = PLAZ-moe · Plazmet = PLAZ-met · Gloopa = GLOO-pah · Tidaloid = TIE-dah-loyd · Sporix = SPOR-ix · Mycelith = MY-seh-lith · Vashti = VASH-tee · Ystra = ISS-trah · Thalassa = thah-LASS-ah · Glyphos = GLIFF-oss · Neonis = nee-ON-iss · Glacia = GLAY-see-ah · Anvilox = ANN-vil-ox · Lumislug = LOO-mih-slug · Monolet = MON-oh-let · Skitterdrone = SKIT-er-drone.

## Rules
- Make exactly the edits listed. Don't rewrite, fix or "improve" any wording.
- If an OLD TEXT can't be found because the project text differs, search for a few distinctive words from the middle of it. If it still isn't there, skip that edit, note it in the log, and carry on.
- Stop and ask me before anything that costs credits beyond these chapters, before deleting a chapter, and before changing any voice's settings.
- Keep a running log (chapter → edits done → new speakers/voices → credits used → problems) and give it to me at the end.

---

The edits for each chapter are in the numbered files in this folder (ch01.md, ch02.md, ...). Do them in order.
