# Alienmon Book 1 — Character Render Prompts (game style)

Every character in *Alienmon: The Kessler Signal* as a copy-paste prompt for a game character sheet. Each prompt is built from the book's descriptions (book wins on looks; where the book is silent, the current game sprite's look is kept) and the game's existing pixel-art style.

## How to use
1. Paste one character's **Prompt** into ChatGPT image generation (landscape, 1536×1024). The prompt already contains the full style block and the exact sheet layout.
2. Check the result: white background, bust top-left, full body top-middle, 4×4 walk grid top-right, poses and faces along the bottom, nothing touching. Regenerate if the grid is uneven.
3. Save it as `art/raw/<key>_sheet.png` and import it:
   - Rook (player): `python tools/import_character_sheet.py art/raw/boy_sheet.png boy --player`
   - Everyone else: `python tools/import_character_sheet.py art/raw/<key>_sheet.png <key>`
   - Add `--holes` only for characters with gaps in their hair and no white clothing (never for Helix, Vashti or anyone in white).
   This writes the 64 px walk frames, the 128 px (160 px for Rook) overworld sprite and the 384 px dialogue portrait.
4. The **Optional detailed render** under each prompt is a single 1024×1024 high-detail bust/portrait for dialogue art, the website or book promos.
5. Ystra (the Seedmother vision) and the Crater Four photo are key-art prompts, not sheets.

Render priority 1 first: they appear in Book 1 story scenes. Characters marked **replace** have a game sprite today that doesn't match the book (Kit, Hank and Strand most of all).

